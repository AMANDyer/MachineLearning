def main():
    print("Hello from deltro!")


if __name__ == "__main__":
    main()
